package com.test.BootP01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootP01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
