package com.test.SecurityP01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityP01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
